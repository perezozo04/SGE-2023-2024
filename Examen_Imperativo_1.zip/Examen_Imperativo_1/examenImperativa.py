import random


num_dia=0
def generar_ciudad(filas, columnas):
    # Crear la matriz inicial con todas las casillas "SANO"
    ciudad = [["SANO" for _ in range(columnas)] for _ in range(filas)]

    # Generar una posición aleatoria para la persona infectada
    fila_infectada = random.randint(0, filas - 1)
    columna_infectada = random.randint(0, columnas - 1)

    # Insertar a la persona infectada en la posición aleatoria
    ciudad[fila_infectada][columna_infectada] = "I-0"

    return ciudad


# Pedir al usuario el número de filas y columnas
num_filas = int(input("Introduce el número de filas: "))
num_columnas = int(input("Introduce el número de columnas: "))


# Llamar a la función GenerarCiudad con los parámetros proporcionados por el usuario
matriz_generada = generar_ciudad(num_filas, num_columnas)

def MostrarCiudad(matriz_generada, num_dia):
# Imprimir la matriz generada
    print(f"DIA: {num_dia}")
    for fila in matriz_generada:
        print(fila)
MostrarCiudad(matriz_generada,num_dia)



def Contagiar(matriz_generada):


  # Inicializamos el número de días que ha tardado en infectar a 0.


  # Recorremos la matriz de personas.
  for i in range(len(matriz_generada)):
    for j in range(len(matriz_generada[0])):
      # Si la persona está infectada, infectamos a las personas que se encuentran a
      # una distancia de 1 en cualquier dirección.
      if matriz_generada[i][j] == "I-0":
        # Infectamos a la persona que está a la derecha.
        if j < len(matriz_generada[0]) - 1 and matriz_generada[i][j + 1] == "SANO":
          matriz_generada[i][j + 1] = "I-1"

        # Infectamos a la persona que está debajo.
        if i < len(matriz_generada) - 1 and matriz_generada[i + 1][j] == "SANO":
          matriz_generada[i + 1][j] = "I-1"

        # Infectamos a la persona que está a la izquierda.
        if j > 0 and matriz_generada[i][j - 1] == "SANO":
          matriz_generada[i][j - 1] = "I-1"

        # Infectamos a la persona que está encima.
        if i > 0 and matriz_generada[i - 1][j] == "SANO":
          matriz_generada[i - 1][j] = "I-1"

  # Retornamos el número de días que ha tardado en infectar.
  return matriz_generada

MostrarCiudad(matriz_generada,num_dia)