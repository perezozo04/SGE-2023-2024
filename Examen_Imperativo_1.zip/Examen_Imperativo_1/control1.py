#Francisco Jiménez García 27-01-2024
import random
def GenerarCiudad(f,c):
    aleatorioF = random.randint(0, f -1)
    aleatorioC = random.randint(0, c -1)    
    matriz = list()
    fila = ["SANO"]*c    
    for i in range(f):
        fila=["SANO"]
        for j in range(c):    
            fila.append("SANO")
        matriz.append(fila)    
    matriz[aleatorioF][aleatorioC] = "I-0 "
    
    return matriz

def MostrarCiudad(m,d):
    print(f"Día {d}")
    for i in range(len(m)):
        for j in range(len(m[i])):
            print(m[i][j], end=" ")
        print()
        
def SanoEnMatriz(matriz):
    for fila in matriz:
        if "SANO" in fila:
            return True
    return False

def Contagiar(m):    
    dias = 0    
    while SanoEnMatriz(matriz):
        MostrarCiudad(m,dias)
        dias+=1
        for i in range(len(m)):            
            for j in range(len(m[i])):
                if(m[i][j] != "SANO" and m[i][j] == "I-"+str(dias-1)+" "):
                    if i == 0 and m[i+1][j] == "SANO":                        
                        m[i+1][j] = "I-" + str(dias) + " "
                    if i == len(m)-1 and m[i-1][j] == "SANO":                        
                        m[i-1][j] = "I-" + str(dias) + " "
                    if i != 0 and i != len(m)-1:                        
                        if m[i+1][j] == "SANO":
                            m[i+1][j] = "I-" + str(dias) + " "
                        if m[i-1][j] == "SANO":
                            m[i-1][j] = "I-" + str(dias) + " "                                
                                                
                        
                    
                    if j == 0 and m[i][j+1] == "SANO":                        
                        m[i][j+1] = "I-" + str(dias) + " "
                    if j == len(m[0])-1 and m[i][j-1] == "SANO":                                                
                        m[i][j-1] = "I-" + str(dias) + " "
                    if j != 0 and j != len(m[0])-1:                                             
                        if m[i][j+1] == "SANO":
                            m[i][j+1] = "I-" + str(dias) + " "
                        if m[i][j-1] == "SANO":
                            m[i][j-1] = "I-" + str(dias) + " "
        
    MostrarCiudad(m,dias)

                
    
filas = int(input("Introduce el numero de filas: "))
columnas = int(input("Introduce el numero de columnas: "))

matriz = GenerarCiudad(filas,columnas)

Contagiar(matriz)
