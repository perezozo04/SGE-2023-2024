import random

# Pide el número de filas y columnas.
nFilas = int(input("Filas: "))
nColumnas = int(input("Columnas: "))


def GenerarCiudad(nFilas, nColumnas):
    infectado = [random.randint(0, nFilas - 1), random.randint(0, nColumnas - 1)]
    ciudad = []
    # El bucle for es porque debe generar toda la matriz.
    for i in range(nFilas):
        fila = []
        for j in range(nColumnas):
            if i == infectado[0] and j == infectado[1]:
                fila.append("I-0")
            else:
                fila.append("SANO")
        ciudad.append(fila)
    return ciudad


def MostrarCiudad(matriz, dia):
    print(f"Día: {dia}")
    for fila in matriz:
        for columna in fila:
            print(columna, end=" ")
        print()


def Contagiar(matriz):
    dias = 0
    # Como ya existe el paciente 0, el contador empieza en 1.
    contagiados = 1
    # Calcula las filas de la matriz, aunque en este caso están almacenadas en nFilas.
    filas = len(matriz)
    # Igual que con las filas, calcula la cantidad de columnas tomando la primera fila de referencia.
    columnas = len(matriz[0])
    # Muestra la ciudad el día 0, antes de comenzar el bucle.
    MostrarCiudad(matriz, dias)
    while contagiados < (filas * columnas):
        dias += 1
        i = 0
        while i < filas:
            j = 0
            while j < columnas:
                # Localiza los contagios del día anterior.
                if matriz[i][j] == (f"I-{dias-1}"):
                    # Entiendo que con "máximo 4 personas" se refiere a que estén disponibles las 4 celdas, aunque también se podría aleatorizar el número de contagios.
                    # En cada caso comprueba que la celda no se sale de los límites del array ni que esté previamente contagiada.
                    if i > 0 and not matriz[(i - 1)][j].startswith("I-"):
                        matriz[(i - 1)][j] = f"I-{dias}"
                        contagiados += 1
                    if i < (nFilas - 1) and not matriz[(i + 1)][j].startswith("I-"):
                        matriz[(i + 1)][j] = f"I-{dias}"
                        contagiados += 1
                    if j > 0 and not matriz[i][j - 1].startswith("I-"):
                        matriz[i][j - 1] = f"I-{dias}"
                        contagiados += 1
                    if j < (nColumnas - 1) and not matriz[i][j + 1].startswith("I-"):
                        matriz[i][j + 1] = f"I-{dias}"
                        contagiados += 1
                j += 1
            i += 1
        MostrarCiudad(matriz, dias)
        print()
    return dias


# Genera una ciudad y luego ejecuta Contagiar (e imprime el resultado final).
ciudadGenerada = GenerarCiudad(nFilas, nColumnas)
print(f"Días totales: {Contagiar(ciudadGenerada)}")
