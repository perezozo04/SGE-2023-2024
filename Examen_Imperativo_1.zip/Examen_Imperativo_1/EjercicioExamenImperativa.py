#Alumno: Juan Hernández López
#Fecha: 27/01/2024
#Ejercicio: ExamenImperativoPython

import random
#primero genero las funciones que voy a utilizar
def GenerarCiudad(num_filas, num_columnas):
    return [["SANO" for _ in range(num_columnas)] for _ in range(num_filas)]

def insertar_IO(matriz):
    fila_aleatoria, columna_aleatoria = random.randint(0, len(matriz) - 1), random.randint(0, len(matriz[0]) - 1)
    matriz[fila_aleatoria][columna_aleatoria] = "I-0"

def MostrarCiudad(matriz, dia=None):
    print(f"Matriz en el día {dia}:" if dia is not None else "Matriz:")
    for fila in matriz:
        print(" ".join(fila))

def Contagiar(matriz):
    direcciones = [(-1, 0), (0, 1), (1, 0), (0, -1)]
    #arriba, derecha, abajo, izquierda, genero

    for i in range(len(matriz)):
        for j in range(len(matriz[0])):
            if matriz[i][j].startswith("I-"):
                # La función startswith("I-") 
                #devuelve True si el contenido de la celda comienza con la cadena "I-", 
                #indicando que la persona en esa posición está infectada.
                for direccion in direcciones:
                    fila_contagio, columna_contagio = i + direccion[0], j + direccion[1]
                    #direccion0 filas, direccion 1 columnas

                    if 0 <= fila_contagio < len(matriz) and 0 <= columna_contagio < len(matriz[0]):
                        if not matriz[fila_contagio][columna_contagio].startswith("I-"):
                            matriz[fila_contagio][columna_contagio] = f"I-{int(matriz[i][j].split('-')[1]) + 1}"

    return matriz

# Solicitar al usuario el número de filas y columnas
num_filas = int(input("Ingrese el número de filas: "))
num_columnas = int(input("Ingrese el número de columnas: "))

# Generar y mostrar la ciudad
matriz_creada = GenerarCiudad(num_filas, num_columnas)
print("Matriz inicial:")
MostrarCiudad(matriz_creada)

# Insertar "I-0" y mostrar la ciudad nuevamente
insertar_IO(matriz_creada)
print("\nMatriz después de insertar 'I-0':")
MostrarCiudad(matriz_creada)

# Simular contagio y mostrar la ciudad en cada día
dias_simulacion = 0
while any("SANO" in fila for fila in matriz_creada): #se ejecuta mientras haya una persona sana
    matriz_creada = Contagiar(matriz_creada)
    dias_simulacion += 1

MostrarCiudad(matriz_creada, dias_simulacion)
print(f"\nTodos están infectados en el día {dias_simulacion}.")
