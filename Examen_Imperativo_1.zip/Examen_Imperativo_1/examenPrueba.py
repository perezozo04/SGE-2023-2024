import random


# Examen hecho por Marcos Calero Fuentes

def GenerarCiudad(filas, columnas):
    matriz = []
    aletorioColumnas = random.randint(0, columnas - 1)

    aletorioFilas = random.randint(0, filas - 1)

    for i in range(filas):
        fila = []
        for j in range(columnas):

            if j == aletorioFilas and i == aletorioColumnas:
                fila.append("1-0")
            else:
                fila.append("SANO")

        matriz.append(fila)
    return matriz


def MostrarCiudad(matriz, dia):
    print("Día: ", dia)
    print()
    for fila in matriz:
        print(fila)


def Contagiar(matriz):
    dia = 1
    contagios = 1
    i = 0
    j = 0
    while dia < 3:
        while i < filas:

            while j < columnas:

                if matriz[i][j] != "SANO" and matriz[i][j] != "1-" + str(dia):

                    if j + 1 <= columnas - 1 and matriz[i][j + 1] == "SANO":
                        matriz[i][j + 1] = "1-" + str(dia)
                        contagios += 1
                    if j - 1 >= 0 and matriz[i][j - 1] == "SANO":
                        matriz[i][j - 1] = "1-" + str(dia)
                        contagios += 1
                    if i + 1 <= filas - 1 and matriz[i + 1][j] == "SANO":
                        matriz[i + 1][j] = "1-" + str(dia)
                        contagios += 1
                    if i - 1 >= 0 and matriz[i - 1][j] == "SANO":
                        matriz[i - 1][j] = "1-" + str(dia)
                        contagios += 1
                j += 1
            j = 0
            i += 1
        dia += 1
        MostrarCiudad(matriz, dia)
        print(contagios)


filas = int(input("Introduce el numero de filas: "))
columnas = int(input("Introduce el numero de columnas: "))

dia = 0
ciudad = GenerarCiudad(filas, columnas)
MostrarCiudad(ciudad, dia)
Contagiar(ciudad)
