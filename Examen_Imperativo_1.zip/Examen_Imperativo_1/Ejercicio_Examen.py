import random

ciudad = []
dias = 0
filas = int(input("Escribe el numero de filas: "))
columnas = int(input("Escribe el numero de columnas: "))

def GenerarCiudad(filas,columnas):
    for i in range(filas):
        ciudad.append(["SANO"] * columnas)

    Infectado0F = random.randint(0,filas -1)
    Infectado0C = random.randint(0, columnas -1)

    ciudad[Infectado0F][Infectado0C] = "I-0"

    return ciudad

def MostrarCiudad(dias, ciudad):
    print(f"Dias: {dias}")
    for e in ciudad:
        for i in e:
            print(i, end="\t")
        print()

def Contagiar(ciudad):
    infectado = True
    dias = 1

    while infectado:
        infectado = False 
        nueva_ciudad = ciudad.copy()

        for i in range(filas):
            for j in range(columnas):
             if ciudad[i][j].startswith("I"):
                if i - 1 >= 0 and nueva_ciudad[i - 1][j] == "SANO":
                    nueva_ciudad[i - 1][j] = f"I-{dias}" 
                    infectado = True
                if j - 1 >= 0 and nueva_ciudad[i][j - 1] == "SANO":
                    nueva_ciudad[i][j - 1] = f"I-{dias}"  
                    infectado = True
                if j + 1 < columnas and nueva_ciudad[i][j + 1] == "SANO":
                    nueva_ciudad[i][j + 1] = f"I-{dias}"  
                    infectado = True
                if i + 1 < filas and nueva_ciudad[i + 1][j] == "SANO":
                    nueva_ciudad[i + 1][j] = f"I-{dias}" 
                    infectado = True
                    
        ciudad = nueva_ciudad
        if infectado:
            MostrarCiudad(dias, ciudad)
            dias += 1

    print(f"Dias totales: {dias-1}")

GenerarCiudad(filas, columnas)
MostrarCiudad(dias, ciudad)
Contagiar(ciudad)
