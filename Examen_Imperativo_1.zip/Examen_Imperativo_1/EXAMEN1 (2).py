import random

def GenerarCiudad(filas, columnas):
    L = []
    for i in range(filas):
        L.append([])
        for j in range(columnas):
            L[i].append("SANO")

    numerofila = random.randint(0, filas - 1)
    numerocolumna = random.randint(0, columnas - 1)
    L[numerofila][numerocolumna] = "I-0"
    
    return L

def MostrarCiudad(L, dia):
    print("DIA:", dia)
    for i in L:
        print(i)

def Contagiar(L, filas, columnas):
    dia = 0
    MostrarCiudad(L, dia)
    TotalCasillas = filas * columnas - 1
    while TotalCasillas != 0:
        for i in range(filas):
            for j in range(columnas):
                if L[i][j] == f"I-{dia}":
                    dia += 1
                    if i - 1 >= 0 and L[i - 1][j] == "SANO":
                        L[i - 1][j] = "I-" + str(dia)
                        TotalCasillas -= 1

                    if i + 1 < filas and L[i + 1][j] == "SANO":
                        L[i + 1][j] = "I-" + str(dia)
                        TotalCasillas -= 1

                    if j - 1 >= 0 and L[i][j - 1] == "SANO":
                        L[i][j - 1] = "I-" + str(dia)
                        TotalCasillas -= 1

                    if j + 1 < columnas and L[i][j + 1] == "SANO":
                        L[i][j + 1] = "I-" + str(dia)
                        TotalCasillas -= 1
                    MostrarCiudad(L, dia)

filas = int(input("Introduce el numero de filas: "))
columnas = int(input("Introduce el numero de columnas: "))
L = GenerarCiudad(filas, columnas)
Contagiar(L, filas, columnas)
