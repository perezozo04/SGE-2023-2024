import random

def GenerarCiudad(numFilas, numColumnas):
    matrix = [["SANO"  for _ in range(numColumnas)] for _ in range(numFilas)]
    filaRandom = random.randrange(numFilas)
    colRandom = random.randrange(numColumnas)
    matrix[filaRandom][colRandom] = "I-0"
    return matrix

def MostrarCiudad(numDia, matrix):
    print(f"Dia: {numDia}\n")

    for x in matrix:
        print(f"\t{x}")

def contagiar(matrix):
    dayCounter = 0
    index = 0
    while index < len(matrix):
        MostrarCiudad(dayCounter, matrix)
        x = f"I-{dayCounter}"
        for i in range(len(matrix)):
            for j in range(len(matrix[i])):
                element = matrix[i][j]
                if element == f"I-{dayCounter}":
                    if matrix[i - 1][j] ==  "SANO" and i > 0:
                        matrix[i - 1][j] = f"I-{dayCounter + 1}"
                    if matrix[i + 1][j] == "SANO" and i < len(matrix)-2:
                        matrix[i + 1][j] = f"I-{dayCounter + 1}"
                    if matrix[i][j - 1] == "SANO" and j > 0:
                        matrix[i][j - 1] = f"I-{dayCounter + 1}"
                    if matrix[i][j + 1] == "SANO" and j < len(matrix)-2:
                        matrix[i][j + 1] = f"I-{dayCounter + 1}"
        dayCounter += 1

numFilas = int(input("Introduzca numero de filas: "))
numColumnas = int(input("Introduzca numer de columnas: "))

myMatrix = GenerarCiudad(numFilas, numColumnas)
contagiar(myMatrix)

#if matrix[i - 1][j] == "SANO" and matrix.index(matrix[i - 1][j]) < len(matrix) and matrix.index(matrix[i - 1][j]) > 0:
 #   matrix[i - 1][j] = matrix[i + 1][j] = matrix[i][j - 1] = matrix[i][j + 1] = f"I-{dayCounter + 1}"