from random import randint


def GenerarCiudad(fila,columna):
    randomFila = randint(0,fila-1)
    randomColumna = randint(0,columna-1)
    listaSano = [["SANO" for _ in range(columna)] for _ in range(fila)]
    listaSano[randomFila][randomColumna] = "I-0"
    return listaSano

def MostrarCiudad(matrixCiudad,dia):
    print(f"Día {dia}:")
    for fila in range(len(matrixCiudad)):
        for columna in range(len(matrixCiudad[fila])):
            print(matrixCiudad[fila][columna],end="\t")
        print()

def Contagiar(matrixCiudad):
    global dia
    dia += 1
    if dia == 1:
        for fila in range(len(matrixCiudad)):
            if "I-0" in matrixCiudad[fila]:
                posiPacienteCero = (fila,matrixCiudad[fila].index("I-0"))
        posicionPacienteX = posiPacienteCero[0]
        posicionPacienteY = posiPacienteCero[1]
    else:
        posicionesPacientes = []
        for fila in range(len(matrixCiudad)):
            for columna in range(len(matrixCiudad[fila])):
                if f"I-{dia-1}" == matrixCiudad[fila][columna]:
                    posicionesPacientes.append([fila,columna])

    if dia == 1:
        if posicionPacienteX == 0:
            if posicionPacienteY == 0:
                derecha = matrixCiudad[posicionPacienteX+1][posicionPacienteY]
                abajo = matrixCiudad[posicionPacienteX][posicionPacienteY+1]
                if derecha == abajo == "SANO":
                    print("Estoy arriba del todo a la izquierda")
                    matrixCiudad[posicionPacienteX+1][posicionPacienteY] = f"I-{dia}"
                    matrixCiudad[posicionPacienteX][posicionPacienteY+1] = f"I-{dia}"
            elif posicionPacienteY == optionColumna-1:
                derecha = matrixCiudad[posicionPacienteX+1][posicionPacienteY]
                arriba = matrixCiudad[posicionPacienteX][posicionPacienteY-1]
                if derecha == arriba == "SANO":
                    print("Estoy abajo del todo a la izquierda")
                    matrixCiudad[posicionPacienteX+1][posicionPacienteY] = f"I-{dia}"
                    matrixCiudad[posicionPacienteX][posicionPacienteY-1] = f"I-{dia}"
            else:
                arriba = matrixCiudad[posicionPacienteX][posicionPacienteY-1]
                derecha = matrixCiudad[posicionPacienteX+1][posicionPacienteY]
                abajo = matrixCiudad[posicionPacienteX][posicionPacienteY+1]
                if arriba == derecha == abajo == "SANO":
                    print("Estoy en medio a la izquierda")
                    matrixCiudad[posicionPacienteX][posicionPacienteY-1] = f"I-{dia}"
                    matrixCiudad[posicionPacienteX+1][posicionPacienteY] = f"I-{dia}"
                    matrixCiudad[posicionPacienteX][posicionPacienteY+1] = f"I-{dia}"
        elif posicionPacienteX == optionFila-1:
            if posicionPacienteY == 0:
                izquierda = matrixCiudad[posicionPacienteX-1][posicionPacienteY]
                abajo = matrixCiudad[posicionPacienteX][posicionPacienteY+1]
                if izquierda == abajo == "SANO":
                    print("Estoy a la derecha del todo arriba")
                    matrixCiudad[posicionPacienteX-1][posicionPacienteY] = f"I-{dia}"
                    matrixCiudad[posicionPacienteX][posicionPacienteY+1] = f"I-{dia}"
            elif posicionPacienteY == optionColumna-1:
                izquierda = matrixCiudad[posicionPacienteX-1][posicionPacienteY]
                arriba = matrixCiudad[posicionPacienteX][posicionPacienteY-1]
                if izquierda == arriba == "SANO":
                    print("Estoy a la derecha del todo abajo")
                    matrixCiudad[posicionPacienteX-1][posicionPacienteY] = f"I-{dia}"
                    matrixCiudad[posicionPacienteX][posicionPacienteY-1] = f"I-{dia}"
            else:
                arriba = matrixCiudad[posicionPacienteX][posicionPacienteY-1]
                abajo = matrixCiudad[posicionPacienteX][posicionPacienteY+1]
                derecha = matrixCiudad[posicionPacienteX+1][posicionPacienteY]
                if arriba == derecha == abajo == "SANO":
                    print("Estoy a la derecha del todo en medio")
                    matrixCiudad[posicionPacienteX][posicionPacienteY-1] = f"I-{dia}"
                    matrixCiudad[posicionPacienteX+1][posicionPacienteY] = f"I-{dia}"
                    matrixCiudad[posicionPacienteX][posicionPacienteY+1] = f"I-{dia}"
        else:
            arriba = matrixCiudad[posicionPacienteX][posicionPacienteY-1]
            derecha = matrixCiudad[posicionPacienteX+1][posicionPacienteY]
            izquierda = matrixCiudad[posicionPacienteX-1][posicionPacienteY]
            abajo = matrixCiudad[posicionPacienteX][posicionPacienteY+1]
            if arriba == derecha == izquierda == abajo == "SANO":
                print(f"Soy derecha {derecha}")
                matrixCiudad[posicionPacienteX][posicionPacienteY-1] = f"I-{dia}"
                matrixCiudad[posicionPacienteX-1][posicionPacienteY] = f"I-{dia}"
                matrixCiudad[posicionPacienteX+1][posicionPacienteY] = f"I-{dia}"
                matrixCiudad[posicionPacienteX][posicionPacienteY+1] = f"I-{dia}"
    else:
        for posicionesPaciente in posicionesPacientes:
            posicionPacienteX = posicionesPaciente[0]
            posicionPacienteY = posicionesPaciente[1]
            
            if posicionPacienteX == 0:
                if posicionPacienteY == 0:
                    derecha = matrixCiudad[posicionPacienteX+1][posicionPacienteY]
                    abajo = matrixCiudad[posicionPacienteX][posicionPacienteY+1]
                    if derecha == abajo == "SANO":
                        print("Estoy arriba del todo a la izquierda")
                        matrixCiudad[posicionPacienteX+1][posicionPacienteY] = f"I-{dia}"
                        matrixCiudad[posicionPacienteX][posicionPacienteY+1] = f"I-{dia}"
                elif posicionPacienteY == optionColumna-1:
                    derecha = matrixCiudad[posicionPacienteX+1][posicionPacienteY]
                    arriba = matrixCiudad[posicionPacienteX][posicionPacienteY-1]
                    if derecha == arriba == "SANO":
                        print("Estoy abajo del todo a la izquierda")
                        matrixCiudad[posicionPacienteX+1][posicionPacienteY] = f"I-{dia}"
                        matrixCiudad[posicionPacienteX][posicionPacienteY-1] = f"I-{dia}"
                else:
                    arriba = matrixCiudad[posicionPacienteX][posicionPacienteY-1]
                    derecha = matrixCiudad[posicionPacienteX+1][posicionPacienteY]
                    abajo = matrixCiudad[posicionPacienteX][posicionPacienteY+1]
                    if arriba == derecha == abajo == "SANO":
                        print("Estoy en medio a la izquierda")
                        matrixCiudad[posicionPacienteX][posicionPacienteY-1] = f"I-{dia}"
                        matrixCiudad[posicionPacienteX+1][posicionPacienteY] = f"I-{dia}"
                        matrixCiudad[posicionPacienteX][posicionPacienteY+1] = f"I-{dia}"
            elif posicionPacienteX == optionFila-1:
                if posicionPacienteY == 0:
                    izquierda = matrixCiudad[posicionPacienteX-1][posicionPacienteY]
                    abajo = matrixCiudad[posicionPacienteX][posicionPacienteY+1]
                    if izquierda == abajo == "SANO":
                        print("Estoy a la derecha del todo arriba")
                        matrixCiudad[posicionPacienteX-1][posicionPacienteY] = f"I-{dia}"
                        matrixCiudad[posicionPacienteX][posicionPacienteY+1] = f"I-{dia}"
                elif posicionPacienteY == optionColumna-1:
                    izquierda = matrixCiudad[posicionPacienteX-1][posicionPacienteY]
                    arriba = matrixCiudad[posicionPacienteX][posicionPacienteY-1]
                    if izquierda == arriba == "SANO":
                        print("Estoy a la derecha del todo abajo")
                        matrixCiudad[posicionPacienteX-1][posicionPacienteY] = f"I-{dia}"
                        matrixCiudad[posicionPacienteX][posicionPacienteY-1] = f"I-{dia}"
                else:
                    arriba = matrixCiudad[posicionPacienteX][posicionPacienteY-1]
                    abajo = matrixCiudad[posicionPacienteX][posicionPacienteY+1]
                    derecha = matrixCiudad[posicionPacienteX+1][posicionPacienteY]
                    if arriba == derecha == abajo == "SANO":
                        print("Estoy a la derecha del todo en medio")
                        matrixCiudad[posicionPacienteX][posicionPacienteY-1] = f"I-{dia}"
                        matrixCiudad[posicionPacienteX+1][posicionPacienteY] = f"I-{dia}"
                        matrixCiudad[posicionPacienteX][posicionPacienteY+1] = f"I-{dia}"
            else:
                arriba = matrixCiudad[posicionPacienteX][posicionPacienteY-1]
                derecha = matrixCiudad[posicionPacienteX+1][posicionPacienteY]
                izquierda = matrixCiudad[posicionPacienteX-1][posicionPacienteY]
                abajo = matrixCiudad[posicionPacienteX][posicionPacienteY+1]
                if arriba == derecha == izquierda == abajo == "SANO":
                    print(f"Soy derecha {derecha}")
                    matrixCiudad[posicionPacienteX][posicionPacienteY-1] = f"I-{dia}"
                    matrixCiudad[posicionPacienteX-1][posicionPacienteY] = f"I-{dia}"
                    matrixCiudad[posicionPacienteX+1][posicionPacienteY] = f"I-{dia}"
                    matrixCiudad[posicionPacienteX][posicionPacienteY+1] = f"I-{dia}"
    return matrixCiudad
optionFila = int(input("Dime el número de filas "))
optionColumna = int(input("Dime el número de columnas "))
dia = 0
ciudad = GenerarCiudad(optionFila,optionColumna)
MostrarCiudad(ciudad,dia)
while not "SANO" in ciudad:
    MostrarCiudad(Contagiar(ciudad),dia)
