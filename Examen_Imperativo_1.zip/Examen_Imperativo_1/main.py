# Realizado por Miguel Sanchez
from random import randint

infectado = 0

def generarCiudad(rows, columns):
    matriz = []
    for i in range(rows):
        actual = []
        for j in range(columns):
            actual.append("sano")
        matriz.append(actual)
    aleatorio_fila = randint(0, rows - 1)
    aleatorio_column = randint(0, columns - 1)
    matriz[aleatorio_fila][aleatorio_column] = "I-" + str(infectado) + " "
    return matriz

def contagiar(matriz):
    filas = len(matriz)
    dia_actual = 0
    for i in range(filas):
        # si filas tiene valor entonces ... sino 0
        columnas = len(matriz[i]) if filas > 0 else 0
        for j in range(columnas):
            if matriz[i][j] == 'sano':
                continue
            # Derecha
            if j < columnas - 1:
                matriz[i][j + 1] = "I-" + str(dia_actual) + " "
            # Izquierda
            if j > 0:
                matriz[i][j - 1] = "I-" + str(dia_actual) + " "
            # Arriba
            if i > 0:
                matriz[i - 1][j] = "I-" + str(dia_actual) + " "
            # Abajo
            if i < filas - 1:
                matriz[i + 1][j] = "I-" + str(dia_actual) + " "
        dia_actual += 1
        print()
        mostrarCiudad(matriz, dia_actual)

def mostrarCiudad(matriz, dia):
    print("Dia:", dia, "\n")
    for row in matriz:
        for j in row:
            print(j, end=' ')
        print()


# filas = int(input("Introduce numero de filas: "))
# columnas = int(input("Introduce numero de columnas"))
matrizCiudad = generarCiudad(3, 3)
contagiar(matrizCiudad)