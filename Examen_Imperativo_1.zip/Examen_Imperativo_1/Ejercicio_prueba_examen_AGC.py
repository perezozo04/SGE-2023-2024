import random


def GenerarCiudad(numFilas, numColumnas):
    matriz = []
    for i in range(numFilas):
        matriz.append(list())
        for j in range(numColumnas):
            matriz[i].append("SANO")
    matriz[random.randint(0, numFilas - 1)][random.randint(
        0, numColumnas - 1)] = "I-0"
    return matriz


def MostarCiudad(ciudad, dia):
    print(f"Dia {dia}")
    for i in range(len(ciudad)):
        print()
        for j in range(len(ciudad[i])):
            print(ciudad[i][j], end="  ")


def Contagiar(matriz):
    infectados = 1
    dia = 0
    MostarCiudad(ciudad, dia)
    while habitantes > infectados:
        dia += 1
        print()

        for i in range(len(matriz)):
            for j in range(len(matriz[i])):
                if matriz[i][j] == "I-"+str(dia - 1):
                    if i+1 < len(matriz) and matriz[i+1][j] == "SANO":
                        matriz[i+1][j] = "I-"+str(dia)
                        infectados += 1

                    if i-1 >= 0 and matriz[i-1][j] == "SANO":
                        matriz[i-1][j] = "I-"+str(dia)
                        infectados += 1

                    if j+1 < len(matriz[i]) and matriz[i][j+1] == "SANO":
                        matriz[i][j+1] = "I-"+str(dia)
                        infectados += 1

                    if j-1 >= 0 and matriz[i][j-1] == "SANO":
                        matriz[i][j-1] = "I-"+str(dia)
                        infectados += 1

        MostarCiudad(ciudad, dia)
        print()
    return dia


numFilas = int(input("Introduce el numero de filas: "))
numColumnas = int(input("Introduce el numero de columnas: "))
habitantes = numFilas * numColumnas
ciudad = GenerarCiudad(numFilas, numColumnas)
print(f"Dias totales: {Contagiar(ciudad)}")
