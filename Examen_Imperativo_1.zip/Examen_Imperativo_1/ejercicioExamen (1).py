import random

def GenerarCiudad(fila, columna):
    fila = int(fila)
    columna = int(columna)
    matriz = [['SANO' for _ in range(columna)] for _ in range(fila)]
    
    ale1 = random.randint(0, fila-1)
    ale2 = random.randint(0, columna-1)
    matriz [ale1][ale2]='I-0'
    
    return matriz
def MostrarCiudad(estado, dia):
    print("\nDia: ",dia)
    for linea in estado:
        print("\t",linea)

def Contagiar(estado):
    diasPasados = 1
    
    while any('SANO' in sublist for sublist in estado):
        for i in range(len(estado)):
            for j in range(len(estado[0])):
                palabra = estado[i][j]
                if palabra=='I-'+str(diasPasados-1):
                    if comprobar(i-1, j, estado):
                        estado[i-1][j]= 'I-'+str(diasPasados)
                    if comprobar (i+1, j, estado):
                        estado[i+1][j]='I-'+str(diasPasados)
                    if comprobar (i, j+1, estado):
                        estado[i][j+1]='I-'+str(diasPasados)
                    if comprobar (i, j-1, estado):
                        estado[i][j-1]='I-'+str(diasPasados)
        MostrarCiudad(estado, diasPasados)
        diasPasados+=1
def comprobar (i, j, matriz):
    try:
        return matriz[i][j]=="SANO"
    except IndexError: 
        return False  
                                           
    
numFila = input("Introduce numero de filas: ")
numColumna = input("Introduce numero de columnas: ")
estado = GenerarCiudad(numFila, numColumna)
MostrarCiudad(estado, 0)

Contagiar(estado)



