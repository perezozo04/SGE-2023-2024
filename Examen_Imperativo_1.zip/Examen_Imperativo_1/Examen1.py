import random

def GenerarCiuad(filas,columnas):
    
    
    matrix = []
    
    for i in range(filas):
        nuevaFila = []
        for j in range(columnas):
            nuevaFila.append("SANO")
        matrix.append(nuevaFila)
        
    matrix[random.randint(0,filas-1)][random.randint(0,columnas-1)] = 'I-0'
        
    return matrix


def MostrarCiudad(matrizGenerada):
    for i in matrizGenerada:
        print(i)

def contagiar(matrizGenerada):
    
    todosContagiados = False
    numero_dia = 0
    
    while not todosContagiados:
        for i in range(len(matrizGenerada)):
            for j in range(len(matrizGenerada[i])):
                if matrizGenerada[i][j] == f"I-{numero_dia}":
                    if j-1 >= 0 and j-1 < len(matrizGenerada[i]) and matrizGenerada[i][j-1] == 'SANO':
                        matrizGenerada[i][j-1] = f"I-{numero_dia+1}" # izquierda
                    if j+1 >= 0 and j+1 < len(matrizGenerada[i]) and matrizGenerada[i][j+1] == 'SANO':  
                        matrizGenerada[i][j+1] = f"I-{numero_dia+1}" #derecha
                    if i-1 >= 0 and i-1 < len(matrizGenerada) and matrizGenerada[i-1][j] == 'SANO':
                        matrizGenerada[i-1][j] = f"I-{numero_dia+1}" #arriba
                    if i+1 >= 0 and i+1 < len(matrizGenerada) and matrizGenerada[i+1][j] == 'SANO':
                        matrizGenerada[i+1][j] = f"I-{numero_dia+1}"  #abajo
        numero_dia+=1
        
        todosContagiados = True
        for fila in matrizGenerada:
            for elemento in fila:
                if elemento == 'SANO':
                    todosContagiados=False
                    
                
        MostrarCiudad(matrizGenerada)
        print("\n")
    
    print(f"Numeros de dias totales {numero_dia} ")

        
    
           
         
    

matrizGenerada = GenerarCiuad(3,3)

MostrarCiudad(matrizGenerada)
print("\n")
contagiar(matrizGenerada)
