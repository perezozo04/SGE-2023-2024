import random

dia = 0

def GenerarCiudad(num_filas, num_columnas):
    ciudad = [["SANO" for _ in range(num_columnas)] for _ in range(num_filas)]
    fila_infectada = random.randint(0, num_filas - 1)
    columna_infectada = random.randint(0, num_columnas - 1)
    ciudad[fila_infectada][columna_infectada] = "I-0"
    return ciudad

def MonstrarCiudad(ciudad, dia):
    print(f"Dia {dia}:")
    for fila in ciudad:
        print(fila)

def ContagiarPersona(ciudad):
    global dia
    # Mientras exista al menos una persona sana
    while any("SANO" in fila for fila in ciudad):
        # Crear una copia de la ciudad
        nueva_ciudad = [fila[:] for fila in ciudad]
        # Recorrer la ciudad
        for fila in range(len(ciudad)):
            for columna in range(len(ciudad[0])):
                # Si la persona está infectada
                if ciudad[fila][columna] == f"I-{dia}":
                    if fila > 0 and ciudad[fila - 1][columna] == "SANO":
                        nueva_ciudad[fila - 1][columna] = f"I-{dia + 1}"
                    if fila < len(ciudad) - 1 and ciudad[fila + 1][columna] == "SANO":
                        nueva_ciudad[fila + 1][columna] = f"I-{dia + 1}"
                    if columna > 0 and ciudad[fila][columna - 1] == "SANO":
                        nueva_ciudad[fila][columna - 1] = f"I-{dia + 1}"
                    if columna < len(ciudad[0]) - 1 and ciudad[fila][columna + 1] == "SANO":
                        nueva_ciudad[fila][columna + 1] = f"I-{dia + 1}"
        dia += 1
        ciudad = nueva_ciudad
        MonstrarCiudad(ciudad, dia)

# Llamar a la función GenerarCiudad
num_filas = int(input("Ingrese el número de filas de la matriz: "))
num_columnas = int(input("Ingrese el número de columnas de la matriz: "))
ciudad_generada = GenerarCiudad(num_filas, num_columnas)
MonstrarCiudad(ciudad_generada, dia)

# Llamar a la función ContagiarPersona
ContagiarPersona(ciudad_generada)

# Mostrar el resultado final
print(f"Todos los habitantes se han contagiado en {dia} días")
