for i in range(0,11):
    print()
    for j in range(0,11):
        print(f"{i} x {j} = {i * j}")