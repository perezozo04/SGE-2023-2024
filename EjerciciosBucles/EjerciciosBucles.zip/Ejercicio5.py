num = int(input("Introduzca un numero: "))
print("Los multiplos son: ")
for i in range (0, num, 11):
    print(i)
