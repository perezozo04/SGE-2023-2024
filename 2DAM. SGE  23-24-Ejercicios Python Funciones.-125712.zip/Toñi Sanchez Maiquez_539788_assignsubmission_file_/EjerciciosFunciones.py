#Ejercicio 1

def factorial(num):

    suma = 1
    if num <400 and num > 0:
        for i in range(1, num+1):
            suma *= i
        print(suma)
    else:
        print("Numero no valido")

num = int (input("Introduce un numero entre 0 y 400: "))
factorial(num)


#Ejercicio 2

def primo(num):
    suma = "2, 3, 5, 7, "
    for i in range (2,num):
        if(i%2!=0 and i%3!=0 and i%5!=0 and i%7!=0):
            suma += str(i)+ ", "
    suma = suma[:-2]
    print(suma)
    
num = int (input("Introduce un numero mayor o igual a 2: "))
primo(num)


#Ejercicio 3

def es_nif(cadena):
    
    letras = ["T", "R", "W", "A", "G", "M", "Y", "F", "P", "D", "X", "B", "N", "J", "Z", "S", "Q", "V", "H", "L", "C", "K", "E"]
   
    caracter = cadena[-1].upper()
    numeros = int(cadena[:-1])
    
    if letras[numeros%23] == caracter:
        return True
    else:
        return False

num = input("Introduce un nif: ")
if es_nif(num):
    print("correcto")
else:
    print("Incorrecto")
    

#€jercicio 4

def letra_nif( num):
     letras = ["T", "R", "W", "A", "G", "M", "Y", "F", "P", "D", "X", "B", "N", "J", "Z", "S", "Q", "V", "H", "L", "C", "K", "E"]
     
     posicion = int(num) % 23
     
     caracter = letras[posicion]
     
     nif=str(num)+caracter
     
     return nif

num = input("Introduce un nif sin caracter y te dire cual le corresponde: ")
resultado = letra_nif(num)
print(resultado)

#Ejercicio 5

def dia_agno(dia, mes, agno):
    dias_por_mes = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    
    if (agno % 4 == 0 and agno % 100 != 0) or (agno % 400 == 0):
        dias_por_mes[1]=29
    print(dias_por_mes[1])  
    diasTotales = dia
    for i in range(mes-1):
        diasTotales += dias_por_mes[i]
       
    return diasTotales

dias = int(input("Introduce un dia: "))
mes = int(input("Introduce un mes: "))
anyo = int(input("Introduce un año: "))

num= dia_agno(dias, mes, anyo)
print(num)


#Ejercicio 6

def es_repeticion(cadena):
    num = len(cadena)
    
    if num%2==0:
        mitad=num//2
        i=0
        while i <mitad and cadena[i]==cadena[i+mitad]:
            i+=1
        if i == mitad:
            return True
        else:
            return False
    else:
        return False
    
cadena = input("Introduce una cadena y comprobare si se repite: ")
print(es_repeticion(cadena))


#Ejercicio 7

def cadenas_de_mayor_longitud (lista):
    
    longitud = len(lista[0])
    newLista = [lista[0]]
    
    for i in range(len(lista)):
        if len(lista[i])> longitud:
            newLista = [lista[i]]
            longitud = len(lista[i])
        elif len(lista[i]) == longitud:
            newLista.append(lista[i])
    return newLista

lista = ["hola", "cascara", "limpiar", "horosco", "ana", "casa"]
newLista = cadenas_de_mayor_longitud(lista)
print(newLista) 

#Ejercicio 8

def añadir_alumno_y_nota(nombre, nota):
    alumnos.append(nombre)
    notas.append(nota)
    
def introducir_datos_alumno():
    nombre = input("Introduce nombre alumno: ")
    nota = float(input("Introduce nota alumno: "))
    añadir_alumno_y_nota(nombre, nota)
    
def mostrar_estudiantes():
    print("\nEstudiantes:\n")
    if len(alumnos)>0:
        for i in range(len(alumnos)):
            print(f"Nombre: {alumnos[i]}, nota: {notas[i]}")
    else:
        print("Primero debe llenar la lista")

def estudiantes_aprobados():
    print("\nAprobados: \n")
    for i in range(len(notas)):
        if notas[i] >=5:
            print(f"Nombre: {alumnos[i]}, nota: {notas[i]}")
            
def numero_aprobados():
    aprobados=0
    for i in range(len(notas)):
        if notas[i] >=5:
            aprobados+=1
    return aprobados

def estudiantes_con_maxima_nota():
    estudiantes = ""
    notaMaxima = 0
    for i in range(len(notas)):
        if notas[i] > notaMaxima:
            estudiantes = "Nombre: "+alumnos[i] +", nota: " +str(notas[i])
            notaMaxima=notas[i]
        elif notas[i]== notaMaxima:
            estudiantes += "\nNombre: "+alumnos[i] +", nota: " +str(notas[i])
    print(estudiantes)
def nota_mayor_media():
    media = sum(notas) / len(notas)
    print("\nAlumnos con nota mayor a la media: ")
    for i in range(len(notas)):
        if notas[i]>= media:
            print(f"Nombre: {alumnos[i]}, nota: {notas[i]}")
  
def nota_alumno():
    nombre = input("Introduce nombre alumno a buscar: ")
    encontrado=False

    for i in range(len(alumnos)):
        if alumnos[i].casefold() == nombre.casefold():
            print(f"Nombre: {alumnos[i]}, nota: {notas[i]}")
            encontrado=True

    if not encontrado:
        print("Alumno no encontrado")
        
            
menu = "1. -Añadir estudiante y calificacion\n2. -Mostrar lista de estudiantes\n3. -Mostrar estudiantes aprobados"
menu+= "\n4. -Numero de aprobados\n5. -Estudiantes con máxima nota\n6. -Estudiantes con nota mayor o igual a la media"
menu+= "\n7. -Nota estudiante\n0. -Finalizar ejecucion del programa"

alumnos = ["Carlos", "Lucia", "Maria", "Antonio", "Luis", "Carmen"]
notas = [5.5, 3.6, 4.4, 9.0, 9.0, 5.5]

print(menu)
opcion = int(input("Introduce numero de opcion: "))

while opcion!=0:
    if opcion==1:
        introducir_datos_alumno()
        print("Alumno añadido")
    elif opcion==2:
        mostrar_estudiantes()
    elif opcion==3:
        estudiantes_aprobados()
    elif opcion==4:
        print(f"\nNumero de aprobados: {numero_aprobados()}")
    elif opcion==5:
        estudiantes_con_maxima_nota()
    elif opcion==6:
        nota_mayor_media()
    elif opcion==7:
        nota_alumno()
    elif opcion==0:
        print("Programa cerrado")
    else:
        print("Opcion no valida")
    print()
    print(menu)
    opcion = int(input("\nIntroduce numero de opcion: "))
    
    
#Ejercicio 10

def duplica(lista):
    newLista = []
    
    for valor in lista:
        newLista.append(valor*2)

    print(newLista)
    
lista = [1,2,3]
duplica(lista)        


#Ejercicio 11

def lista_concatenada(lista):
    
    return lista + lista


lista1 = ["hola", "adios"]
lista2 = lista_concatenada(lista1)
print(lista2)

#Ejercicio 12

def generar_matriz():
    
    matriz = []
    
    import random
    for i in range(random.randint(2, 6)):
        lista = []
        for j in range(random.randint(2,6)):
            lista.append(random.randint(0,100))
        matriz.append(lista)
    
    for elemento in matriz:
        print(elemento)
        
generar_matriz()


#Ejercicicio 13

def generar_matriz():
    #random.randint(2,6)
    import random
    matriz = []
    suma = 0
    filas = random.randint(2,6)
    columnas = random.randint(2,6)
    
    for i in range(filas):
        lista = []
        for j in range(columnas):
            lista.append(random.randint(0,100))
        matriz.append(lista)
    
    if filas == columnas:
        for i in range(len(matriz)):
            for j in range(len(matriz)):
                if i == j:
                    suma+= matriz[i][j]
        print(matriz)
        return suma
    else:
        return "None"

valor= generar_matriz()

while valor == "None":
    valor = generar_matriz()
print(valor)


#Ejercicicio 14

def operaciones_matematicas(operador, parametroBase = 0, *operandos, **ecuacion):
    resultado=0
    if operador=="suma":
        for valor in operandos:
            resultado+=valor
    elif operador =="resta":
        
        






