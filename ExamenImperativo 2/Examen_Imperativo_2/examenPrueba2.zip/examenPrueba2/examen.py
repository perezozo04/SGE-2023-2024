import recorterModule


def MostrarMatriz(matriz):
    for fila in matriz:
        print(fila)
    print()


matrizOriginal = [[1, 2, 3], [4, 1, 1]]
t = recorterModule.Recorter(matrizOriginal)

print("Matriz original ")
MostrarMatriz(matrizOriginal)
print()

print("Matriz Recortada ")
MostrarMatriz(t[0])
print()

print("Matriz Sobrante ")
MostrarMatriz(t[1])
print()
