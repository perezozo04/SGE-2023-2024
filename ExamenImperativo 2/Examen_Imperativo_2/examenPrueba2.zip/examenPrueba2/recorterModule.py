def Recorter(matrizEntrada):
    matriz_recorte = []
    matriz_sobrante = []
    contadorFilas = 0
    contadorMinColumnas = 0
    for i in range(len(matrizEntrada)):
        contadorFilas += 1
        contadorColumnas = len(matrizEntrada[i])
        if i == 0:
            contadorMinColumnas = contadorColumnas
        elif contadorColumnas < contadorMinColumnas:
            contadorMinColumnas = contadorColumnas

    if contadorMinColumnas > contadorFilas:
        numeroRecorte = contadorFilas
    else:
        numeroRecorte = contadorMinColumnas
    i = 0
    while i < numeroRecorte:
        matriz_recorte.append(matrizEntrada[i][:numeroRecorte])

        if len(matrizEntrada[i]) > numeroRecorte:
            matriz_sobrante.append(matrizEntrada[i][numeroRecorte:])
        i += 1

    for i in range(numeroRecorte, len(matrizEntrada)):
        matriz_sobrante.append(matrizEntrada[i])
    return (matriz_recorte, matriz_sobrante)
