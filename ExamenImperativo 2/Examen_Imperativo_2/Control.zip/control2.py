import ModuloControl

matriz = [[1, 2, 3,4], [4,5, 6,2,2], [8, 9,10,2,2],[11,12,13,14] ,[8, 9,2,2,10],[1,3,3,32,3]]
matriz_recorte, matriz_sobrante, matrizFinal = (ModuloControl.Recortes(matriz))

ModuloControl.MostrarMatriz(matriz_recorte)
ModuloControl.MostrarMatriz(matriz_sobrante)
ModuloControl.MostrarMatriz(matriz)
