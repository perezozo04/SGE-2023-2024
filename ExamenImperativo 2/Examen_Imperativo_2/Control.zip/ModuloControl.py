def Recortes(matriz):
    n_filas = len(matriz)
    n_columnas_min = min(len(fila) for fila in matriz)
    print(n_columnas_min)

    matriz_recorte = []
    matriz_sobrante = []
    for fila in matriz:
        j = 0
        filaRecorte = []
        filaSobrante = []
        for elemento in fila:                        
            if j < n_columnas_min and len(matriz_recorte) < n_columnas_min:
                filaRecorte.append(elemento)
            else:
                filaSobrante.append(elemento)
            j+=1
        if filaRecorte  != []:
            matriz_recorte.append(filaRecorte)
        if filaSobrante != []:            
            matriz_sobrante.append(filaSobrante)
    
    
    matrizFinal = (matriz_recorte,matriz_sobrante)
    return matriz_recorte, matriz_sobrante, matrizFinal

def MostrarMatriz(m):
    for fila in m:
        for elemento in fila:
            print(elemento, end="\t")
        print()
    print()