def Recortes(matriz):
    min_columna=len(matriz[0])
    matriz_generada=list()
    matriz_sobrante=list()
    
    
    for i in range(len(matriz)):
        if len(matriz[i])<min_columna:
            min_columna=len(matriz[i])
    
    if min_columna > len(matriz):
        min_columna=len(matriz)
    
    if min_columna>0:

        for i_generada in range(min_columna):
            matriz_generada.append(list())
            for j_generada in range(min_columna):
                matriz_generada[i_generada].append(matriz[i_generada][j_generada])
        

            
        for i_sobrante in range(len(matriz)):
            matriz_sobrante.append(list())

            for j_sobrante in range(len(matriz[i_sobrante])):
                if i_sobrante<min_columna:

                    if j_sobrante >= min_columna:
                        matriz_sobrante[i_sobrante].append(matriz[i_sobrante][j_sobrante])
                else:
                    matriz_sobrante[i_sobrante].append(matriz[i_sobrante][j_sobrante])

        matriz_sobrante_limpia=list(matriz_sobrante)


        for i_limpia in range(len(matriz_sobrante)):
            if len(matriz_sobrante[i_limpia])==0:
                matriz_sobrante_limpia.remove(matriz_sobrante_limpia[i_limpia])

        
        resultado = (matriz_generada,matriz_sobrante_limpia)
        return resultado
    else:
        return "Has introducido una matriz o fila vacia"
    

    


