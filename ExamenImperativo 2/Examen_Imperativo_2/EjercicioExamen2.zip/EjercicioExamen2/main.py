from Recortes import recortes

# Matriz de ejemplo.
matriz = [[1, 2, 3], [4, 5], [6, 7], [8, 9, 10]]

# Se igualan los valores a los de cada elemento de la tupla.
matrizRecortada, matrizSobrante = recortes(matriz)


def MostrarMatriz(m):
    for i in range(len(m)):
        for j in range(len(m[i])):
            print(m[i][j], end="\t")
        print()


print("Matriz Original.")
MostrarMatriz(matriz)

print("\nMatriz Recortada.")
MostrarMatriz(matrizRecortada)

print("\nMatriz Sobrante.")
MostrarMatriz(matrizSobrante)
