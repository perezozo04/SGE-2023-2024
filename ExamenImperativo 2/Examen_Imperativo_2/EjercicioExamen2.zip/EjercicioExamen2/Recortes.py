def recortes(matriz):
    # Guarda las filas de la matriz.
    filas = len(matriz)
    # Se inicializa en la cantidad de filas puesto que buscamos el valor mínimo.
    minColumna = len(matriz)
    for i in range(len(matriz)):
        if len(matriz[i]) < minColumna:
            minColumna = len(matriz[i])

    # Mira si el valor mínimo corresponde a filas o a minColumna y ajusta el otro valor.
    if filas > minColumna:
        filas = minColumna
    else:
        minColumna = filas

    # Se crean las dos matrices vacías.
    matriz_recorte = []
    matriz_sobrante = []
    for i in range(len(matriz)):
        # Se crean dos columnas, una para cada matriz.
        columnaRecorte = []
        columnaSobrante = []
        for j in range(len(matriz[i])):
            # Si está dentro del rango de la matriz cuadrada se añade a columnaRecorte y en caso contrario, a columaSobrante.
            if i < filas and j < minColumna:
                columnaRecorte.append(matriz[i][j])
            else:
                columnaSobrante.append(matriz[i][j])
        # Comprueba si las columnas están vacías antes de añadirlas.
        if len(columnaRecorte) != 0:
            matriz_recorte.append(columnaRecorte)
        if len(columnaSobrante) != 0:
            matriz_sobrante.append(columnaSobrante)

    return matriz_recorte, matriz_sobrante
