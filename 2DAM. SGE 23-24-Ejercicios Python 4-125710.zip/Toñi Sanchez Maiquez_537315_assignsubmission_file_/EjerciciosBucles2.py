#Ejercicio 1

cadena = input("Introduce una frase. Contare el total de cada una de las vocales y consonantes: ")

vocabulario = {'a': 0, 'b': 0, 'c': 0, 'd': 0, 'e': 0, 'f': 0, 'g': 0, 'h': 0, 'i': 0, 'j': 0, 'k': 0, 'l': 0, 'm': 0, 'n': 0, 'ñ': 0, 'o': 0, 'p': 0, 'q': 0, 'r': 0, 's': 0, 't': 0, 'u': 0, 'v': 0, 'w': 0, 'x': 0, 'y': 0, 'z': 0}

cadena = cadena.lower()

for letra in cadena:
    if letra in vocabulario:
        vocabulario[letra] +=1

for caracter, count in vocabulario.items():
    if(count!=0):
        print(caracter, ":", count, end= "")


#€jercicio 2

FEmple = [{'N':15, 'nombre': 'Pepe', 'Categoria': "A", "Pais": 'España'},
          {'N':16, 'nombre': 'Pepe2', 'Categoria': "B", "Pais": 'China'},
          {'N':17, 'nombre': 'Pepe3', 'Categoria': "C", "Pais": 'España'},
          {'N':18, 'nombre': 'Pepe4', 'Categoria': "A", "Pais": 'Francia'}
          ]
SumaCategorias ={'A':0, 'B': 0, 'C':0, 'D':0, 'E':0, 'F':0}
SumaPaises ={'España': 0, 'Francia': 0, 'Alemania':0, 'China': 0}

for E in FEmple:
    SumaCategorias[E['Categoria']] +=1
    SumaPaises[E['Pais']] +=1

for i in range(len(FEmple)):
    SumaCategorias[FEmple[i]['Categoria']] +=1
    SumaPaises[FEmple[i]['Pais']] +=1
    
max =0
pais = ""

for key, value in SumaPaises.items():
    if value > max:
        max = value
        pais = key

print(pais)
#Ejercicio 3

nota = input("Introduce notas de alumnos. Pulsa ENTER para terminar: ")
aprobados = suspendidos = 0
sumaNotas =0
count=0
notas = []

while (nota!=""):
    nota = float(nota)
    count+=1
    sumaNotas += nota
    notas.append(nota)

    if nota <5:
        suspendidos+=1
    else:
        aprobados+=1

    nota = input("Introduce notas de alumnos. Pulsa ENTER para terminar: ")
    
media = sumaNotas // count 
print("Se han introducido las siguientes notas\n ")
for i in range (len(notas)):
    print(f"Notas de alumno {i+1}: {notas[i]}")
print("Resumnen:")
print("Numero de alumnos:", count)
print("Aprobados:", aprobados)
print("Suspendidos:", suspendidos)    
print ("Media:", media)

#€jercicio 4

nombre = input("Introduce un nombre. Pulsa ENTER para terminar: ")
nombres = []

while(nombre!=""):
    
    nombres.append(nombre)
    nombre = input("Introduce un nombre. Pulsa ENTER para terminar: ")

nombres.sort()

for nombre in nombres:
    print(nombre)
    
#€jercicio 6

valor1 = 0
valor2 = 1

fibonacci = [valor1, valor2]

for i in range(98):
    valor3 = valor1 + valor2
    fibonacci.append(valor3)
    valor1 = valor2
    valor2 = valor3

for numero in fibonacci:
    print (numero)


#€jercicio 7

print("Debes rellenar una matriz de 5 por 5. Introduce 5 números, separados por espacio y presiona enter")
listaNum = []
sumaFilas = {1:0, 2:0, 3:0, 4:0, 5:0}
sumaColumnas = {0:0, 1:0, 2:0, 3:0, 4:0}

for i in range(1, 6):
    cadena = input(f"Introduce números fila {i}: ")
    lista = cadena.split()

    fila = []

    for j in range (len(lista)):
        num = int(lista[j])
        sumaFilas[i]+=num
        sumaColumnas[j]+=num
        fila.append(num)

    listaNum.append(fila)

print("Totales filas:", *sumaFilas.values())
print("Totales columnas:", *sumaColumnas.values())


#Ejercicio 8

productos = []
count=0

def crearProducto():
    global count
    count+=1
    if count < 21:
        marca = input("Introduce marca del producto: ")
        modelo = input("Introduce modelo del producto: ")
        descripcion = input("Introduce descripcion del producto: ")
        precio = int(input("Introduce precio del producto: "))
    else:
        print("No se pueden crear mas productos")
    
    producto = {"Marca": marca, "Modelo": modelo, "Descripcion": descripcion, "Precio":precio}
    productos.append(producto)


    
def crearFactura():
    if count==0:
        print("primero debe crear un producto")
    else:
        nombre = input("Introduzca nombre: ")
        dni = input ("Introduzca dni: ")
        direccion = input("Introduzca direccion: ")
        print("\nMARCAS DEL CATALOGO: ")
        # Usar un conjunto para almacenar marcas únicas
        marcasUnicas = set()

        for producto in productos:
            marcasUnicas.add(producto["Marca"])
        print(marcasUnicas)
        marca= input("Introduzca un nombre de marca de los mostrados para iniciar el pedido: ")
        
        for producto in productos:
            if producto["Marca"] == marca:
                print(producto["Modelo"])

        modelo = input("Introduce modelo deseado: ")
        cantidad = int(input("Introduce cantidad: "))
        importe = 0
        for producto in productos:
            if producto["Modelo"] == modelo and producto["Marca"] == marca:
                importe = producto["Precio"]
        iva =0
        precioTotal=0
        if importe !=0:
            iva = importe*0.16
            precioTotal = importe + iva
        else:
            print("Ha introducido una marca o un modelo incorrectos. No se puede realizar el pedido")
            
        print(f"\n  FACTURA\nNombre: {nombre}\nDni: {dni}\nDireccion: {direccion}\n{cantidad} {marca} {modelo} \nPrecio unidad: {importe}\nPrecio con iva(16%): {precioTotal}\nPrecio final: {precioTotal*cantidad}\n")
 
    
menu= "  MENU DE OPCIONES: \n 1. -Crear producto\n 2. -Crear factura \n 0. -Salir"
print(menu)
opcion = input("Introduce numero de opcion: ")

while opcion !="0":
    if opcion == '1':
        crearProducto()
    elif opcion == "2":
        crearFactura()
    else:
        print ("Opcion no valida")
    print(menu)
    opcion = input("Introduce numero de opcion: ")

print("Programa cerrado")


#€jercicio 10

import random

sacoDePalabras = {1:"Palomitas", 2:"Programacion", 3:"Vacaciones", 4:"Deporte", 5:"Chuparraspillas", 
                  6:"Verano", 7:"Libertad", 8:"Margarita", 9:"Macarrones", 10:"Biblioteca",
                  11:"Telescopio", 12:"Horoscopo", 13:"Capricorpio", 14:"Caprichoso", 15:"Cumpleaños",
                  16:"Fiesta", 17:"Aniversario", 18:"Inteligencia", 19:"Pelicula", 20:"Alcachofas"} 

palabra = sacoDePalabras[random.randint(1,20)]


enigma = palabra[0]+"-"*(len(palabra)-2)+palabra[-1]
fallos = 0
letrasJugadas = 0
caracteresIntroducidos = ""

print("¿Te ves capaz de adivinar la palabra secreta? Maximo 6 fallos")

while fallos < 7 and ("-" in enigma):
    
    print(enigma)
    print(f"letras jugadas: {letrasJugadas} ({caracteresIntroducidos})")
    caracter = input("Introduce un caracter: ")
    encontrado = False
    
    if(caracter in caracteresIntroducidos):
        print("Ya has introducido ese carácter")
    else:
        for c in range(len(palabra)):
            if palabra[c]==caracter:
                enigma = enigma[:c] + palabra[c] + enigma[c + 1:]
                encontrado = True
                
        if not encontrado:
            fallos +=1
            if fallos !=7:
                print(f"Error. Te quedan {6-fallos} intentos")
                
        caracteresIntroducidos += caracter + " "
        letrasJugadas+=1
        encontrado=False
    
if "-" in enigma:
    print("Mas suerte la proxima vez")
else:
    print("¡Enhorabuena! Has acertado la palabra")
    







   
    